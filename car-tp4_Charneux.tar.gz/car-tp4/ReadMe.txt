Tp réalisé par Dimitri Charneux.

La partie sur les jsp a été faites.

Après avoir galérer sur l'initialisation des données, j'ai enfin réussi à afficher les auteurs.

Je n'ai pas eu le temps de faire le reste.

Les explications données dans le cours et dans l'énoncé du TP ne m'ont pas aidées...

